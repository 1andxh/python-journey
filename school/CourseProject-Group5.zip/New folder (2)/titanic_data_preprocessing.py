import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from imblearn.over_sampling import SMOTE
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay

# Load the Titanic dataset
titanic_df = pd.read_csv(r'C:\Users\cdk\Downloads\New folder (2)\Titanic-Dataset.csv')

# Handling Missing Data Values
titanic_df['Age'].fillna(titanic_df['Age'].median(), inplace=True)
titanic_df.drop(columns=['Cabin'], inplace=True)
titanic_df['Embarked'].fillna(titanic_df['Embarked'].mode()[0], inplace=True)

# Handling Duplicate Instances
titanic_df.drop_duplicates(inplace=True)

# Data Transformation
titanic_df['Fare_log'] = titanic_df['Fare'].apply(lambda x: np.log(x + 1))

# Feature Selection
titanic_df = pd.get_dummies(titanic_df, columns=['Sex', 'Embarked'], drop_first=True)
features = ['Pclass', 'Age', 'SibSp', 'Parch', 'Fare_log', 'Sex_male', 'Embarked_Q', 'Embarked_S']
X = titanic_df[features]
y = titanic_df['Survived']

# Apply SMOTE to balance the dataset
smote = SMOTE(random_state=42)
X_sm, y_sm = smote.fit_resample(X, y)

# Split the data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X_sm, y_sm, test_size=0.3, random_state=42)

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from imblearn.over_sampling import SMOTE
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay

# Load the Titanic dataset
titanic_df = pd.read_csv(r'C:\Users\cdk\Downloads\New folder (2)\Titanic-Dataset.csv')

# Handling Missing Data Values
titanic_df['Age'].fillna(titanic_df['Age'].median(), inplace=True)
titanic_df.drop(columns=['Cabin'], inplace=True)
titanic_df['Embarked'].fillna(titanic_df['Embarked'].mode()[0], inplace=True)

# Handling Duplicate Instances
titanic_df.drop_duplicates(inplace=True)

# Data Transformation
titanic_df['Fare_log'] = titanic_df['Fare'].apply(lambda x: np.log(x + 1))

# Feature Selection
titanic_df = pd.get_dummies(titanic_df, columns=['Sex', 'Embarked'], drop_first=True)
features = ['Pclass', 'Age', 'SibSp', 'Parch', 'Fare_log', 'Sex_male', 'Embarked_Q', 'Embarked_S']
X = titanic_df[features]
y = titanic_df['Survived']

# Apply SMOTE to balance the dataset
smote = SMOTE(random_state=42)
X_sm, y_sm = smote.fit_resample(X, y)

# Split the data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X_sm, y_sm, test_size=0.3, random_state=42)

# Train a Logistic Regression model
model = LogisticRegression(max_iter=1000)
model.fit(X_train, y_train)

# Predict on the test set
y_pred = model.predict(X_test)

# Compute the confusion matrix
cm = confusion_matrix(y_test, y_pred)

# Create custom labels
class_labels = ['Not Survived', 'Survived']

# Create and plot the confusion matrix with custom labels
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=class_labels)
disp.plot(cmap='Blues')
plt.title('Confusion Matrix')
plt.show()

# Save the preprocessed data for future use
smote_df = pd.DataFrame(X_sm, columns=features)
smote_df['Survived'] = y_sm
smote_df.to_csv('preprocessed_titanic_dataset_with_smote.csv', index=False)

print("Preprocessing, balancing with SMOTE, model training, and confusion matrix visualization completed successfully.")