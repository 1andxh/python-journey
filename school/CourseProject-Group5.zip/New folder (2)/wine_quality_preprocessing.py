import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score

# Load the Wine Quality dataset
wine_df = pd.read_csv('wine-clustering.csv')

# Display first few rows to inspect the data
print(wine_df.head())

# Handling Missing Data Values
wine_df.fillna(wine_df.median(), inplace=True)

# Handling Duplicate Instances
wine_df.drop_duplicates(inplace=True)

# Feature Selection
X = wine_df.drop('Alcohol', axis=1)  # Using 'Alcohol' as the target variable
y = wine_df['Alcohol']

# Split the data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Initialize the model
model = LinearRegression()

# Train the model
model.fit(X_train, y_train)

# Predict on the test set
y_pred = model.predict(X_test)

# Compute the metrics
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)
print(f"Mean Squared Error: {mse}, R2 Score: {r2}")

# Visualize Actual vs Predicted
plt.figure(figsize=(10, 6))
plt.scatter(y_test, y_pred, alpha=0.5)
plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'r--', lw=2)
plt.xlabel('Actual Alcohol Content')
plt.ylabel('Predicted Alcohol Content')
plt.title('Actual vs Predicted Alcohol Content')
plt.tight_layout()
plt.show()

print("Preprocessing, model training, and visualization completed successfully.")