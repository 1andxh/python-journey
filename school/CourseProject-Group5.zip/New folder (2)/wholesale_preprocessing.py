import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
from imblearn.over_sampling import RandomOverSampler

# Load the data
data = pd.read_csv('Wholesale customers data.csv')

# Separate features and target
X = data.drop(['Channel', 'Region'], axis=1)
y = data['Channel']

# Balance the dataset
ros = RandomOverSampler(random_state=42)
X_resampled, y_resampled = ros.fit_resample(X, y)

# Standardize the features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_resampled)

# Perform K-means clustering
kmeans = KMeans(n_clusters=3, random_state=42)
cluster_labels = kmeans.fit_predict(X_scaled)

# Reduce dimensionality for visualization
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X_scaled)

# Create a scatter plot
plt.figure(figsize=(10, 8))
scatter = plt.scatter(X_pca[:, 0], X_pca[:, 1], c=cluster_labels, cmap='viridis')
plt.title('K-means Clustering of Wholesale Customers')
plt.xlabel('First Principal Component')
plt.ylabel('Second Principal Component')
plt.colorbar(scatter, label='Cluster')

# Add channel information to the plot
for channel in y_resampled.unique():
    channel_mask = y_resampled == channel
    plt.scatter(X_pca[channel_mask, 0], X_pca[channel_mask, 1], 
                marker='o', s=100, facecolors='none', 
                edgecolors=['r', 'g', 'b'][channel-1], 
                linewidth=2, label=f'Channel {channel}')

plt.legend()
plt.tight_layout()
plt.show()

# Print cluster centers
cluster_centers = scaler.inverse_transform(kmeans.cluster_centers_)
cluster_centers_df = pd.DataFrame(cluster_centers, columns=X.columns)
print("Cluster Centers:")
print(cluster_centers_df)

# Analyze cluster composition
for cluster in range(3):
    cluster_mask = cluster_labels == cluster
    channel_dist = y_resampled[cluster_mask].value_counts(normalize=True)
    print(f"\nCluster {cluster} composition:")
    print(channel_dist)